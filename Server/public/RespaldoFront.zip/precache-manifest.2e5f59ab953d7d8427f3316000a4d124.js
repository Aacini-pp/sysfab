self.__precacheManifest = [
  {
    "revision": "06cb420eaf710926295f",
    "url": "/static/css/main.88e36dbd.chunk.css"
  },
  {
    "revision": "06cb420eaf710926295f",
    "url": "/static/js/main.06cb420e.chunk.js"
  },
  {
    "revision": "4422e644433f4a61be16",
    "url": "/static/js/1.4422e644.chunk.js"
  },
  {
    "revision": "232ca8a0386e3212d863",
    "url": "/static/css/2.1f7ff547.chunk.css"
  },
  {
    "revision": "232ca8a0386e3212d863",
    "url": "/static/js/2.232ca8a0.chunk.js"
  },
  {
    "revision": "9c15d78cc6e756e21791",
    "url": "/static/js/runtime~main.9c15d78c.js"
  },
  {
    "revision": "06e733283fa43d1dd57738cfc409adbd",
    "url": "/static/media/logo.06e73328.svg"
  },
  {
    "revision": "2ae24d6027febb7dfc8525a4b105770e",
    "url": "/index.html"
  }
];