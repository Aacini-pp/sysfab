self.__precacheManifest = [
  {
    "revision": "f256a98adf5389541563",
    "url": "/static/css/main.1782a5f8.chunk.css"
  },
  {
    "revision": "f256a98adf5389541563",
    "url": "/static/js/main.f256a98a.chunk.js"
  },
  {
    "revision": "4f473d823a9b02f8d234",
    "url": "/static/js/1.4f473d82.chunk.js"
  },
  {
    "revision": "deb4138c1fe7d288ed4e",
    "url": "/static/css/2.7a90cdad.chunk.css"
  },
  {
    "revision": "deb4138c1fe7d288ed4e",
    "url": "/static/js/2.deb4138c.chunk.js"
  },
  {
    "revision": "40857e98b0e4c21baa2e",
    "url": "/static/js/runtime~main.40857e98.js"
  },
  {
    "revision": "06e733283fa43d1dd57738cfc409adbd",
    "url": "/static/media/logo.06e73328.svg"
  },
  {
    "revision": "6eace0e05e8beb347d5adbb4f521f9bb",
    "url": "/index.html"
  }
];