INSERT INTO `CatEstatus` (`id`, `Nombre`, `Descripcion`) VALUES (1, 'Activo', NULL);
INSERT INTO `CatEstatus` (`id`, `Nombre`, `Descripcion`) VALUES (2, 'Sin asignar', NULL);
INSERT INTO `CatEstatus` (`id`, `Nombre`, `Descripcion`) VALUES (3, 'Baja', NULL);
INSERT INTO `CatEstatus` (`id`, `Nombre`, `Descripcion`) VALUES (4, 'No verificado', NULL);
INSERT INTO `CatEstatus` (`id`, `Nombre`, `Descripcion`) VALUES (5, 'Concluido', NULL);
