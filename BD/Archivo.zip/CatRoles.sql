INSERT INTO `CatRoles` (`id`, `Nombre`, `Descripcion`) VALUES (1, 'Visitante', 'Sin indicio de violencia');
INSERT INTO `CatRoles` (`id`, `Nombre`, `Descripcion`) VALUES (2, 'Victima', 'sufre de violencia de algun tipo');
INSERT INTO `CatRoles` (`id`, `Nombre`, `Descripcion`) VALUES (3, 'Voluntaria', 'ayuda a una vitima');
INSERT INTO `CatRoles` (`id`, `Nombre`, `Descripcion`) VALUES (4, 'Coordinadora', 'dirije a las volunatias');
